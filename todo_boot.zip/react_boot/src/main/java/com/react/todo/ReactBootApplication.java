package com.react.todo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactBootApplication.class, args);
	}

}
